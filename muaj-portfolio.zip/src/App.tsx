import { useCallback, useEffect, useRef, useState } from 'react';
import { ActionRow } from './components/ActionRow';
import { ContactSection } from './components/ContactSection';
import { ExperienceAndSkills } from './components/ExperienceAndSkills';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ProficiencyCard } from './components/ProficiencyCard';
import { ProjectGallery } from './components/ProjectGallery';
import { ContactConfig, NavSectionId } from './types/portfolio';

// ============================================================================
// PLACEHOLDER - replace in CONTACT object
// Edit all personal and contact placeholders in this single config block.
// ============================================================================
const CONTACT: ContactConfig = {
  name: 'Muaj Bin Ashraf',
  role: 'Graphic Designer',
  email: 'your@email.com',         // PLACEHOLDER - I will provide
  whatsapp: '8801XXXXXXXXX',       // PLACEHOLDER - digits only, with country code
  phone: '+880 XXXX-XXXXXX',       // PLACEHOLDER - displayed text
  location: 'City, Bangladesh',    // PLACEHOLDER
  social: '#',                     // PLACEHOLDER
};

export default function App() {
  // "About me" starts as the active link as specified
  const [activeSection, setActiveSection] = useState<NavSectionId>('about');
  const homePinnedRef = useRef(false);

  const handleNavigate = useCallback((id: NavSectionId) => {
    setActiveSection(id);

    if (id === 'home') {
      homePinnedRef.current = true;
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    homePinnedRef.current = false;
    const target = document.getElementById(id);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  const handleReadMore = useCallback(() => {
    homePinnedRef.current = false;
    const expSection = document.getElementById('experience');
    if (expSection) {
      expSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const serviceEl = document.getElementById('service');
      const projectEl = document.getElementById('project');
      const offset = 150;

      if (scrollY > 40) {
        homePinnedRef.current = false;
      }

      if (projectEl && scrollY + offset >= projectEl.offsetTop) {
        setActiveSection('project');
      } else if (serviceEl && scrollY + offset >= serviceEl.offsetTop) {
        setActiveSection('service');
      } else if (!homePinnedRef.current) {
        setActiveSection('about');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div id="home" className="min-h-screen flex flex-col">
      <Header activeSection={activeSection} onNavigate={handleNavigate} />

      <main className="portfolio-container page-stack flex-1">
        <HeroSection contact={CONTACT} />
        <ActionRow contact={CONTACT} onReadMore={handleReadMore} />
        <ProficiencyCard />
        <ExperienceAndSkills />
        <ProjectGallery />
        <ContactSection contact={CONTACT} />
      </main>

      <Footer />
    </div>
  );
}
