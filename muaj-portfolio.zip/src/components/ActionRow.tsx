import { ContactConfig } from '../types/portfolio';

interface ActionRowProps {
  contact: ContactConfig;
  onReadMore: () => void;
}

export function ActionRow({ contact, onReadMore }: ActionRowProps) {
  return (
    <div className="action-row">
      <a
        href="#experience"
        onClick={(e) => {
          e.preventDefault();
          onReadMore();
        }}
        className="read-more-btn liquid-glass"
      >
        <span>Read More</span>
        <span aria-hidden="true">↓</span>
      </a>

      {/* PLACEHOLDER - replace in CONTACT object */}
      <a
        href={contact.social}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => {
          if (contact.social === '#') {
            e.preventDefault();
          }
        }}
        className="social-box"
      >
        Your social link here
      </a>
    </div>
  );
}
