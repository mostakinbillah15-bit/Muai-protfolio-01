import { useState } from 'react';
import { ContactConfig } from '../types/portfolio';

interface ContactSectionProps {
  contact: ContactConfig;
}

export function ContactSection({ contact }: ContactSectionProps) {
  const [copied, setCopied] = useState(false);
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [message, setMessage] = useState('');
  const [formStatus, setFormStatus] = useState<string | null>(null);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(contact.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmedName = senderName.trim();
    const trimmedEmail = senderEmail.trim();
    const trimmedMessage = message.trim();

    if (!trimmedName || !trimmedEmail || !trimmedMessage) {
      setFormStatus('Please fill in your name, email, and message.');
      return;
    }

    const subject = encodeURIComponent(`Portfolio Inquiry from ${trimmedName}`);
    const body = encodeURIComponent(
      `Name: ${trimmedName}\nEmail: ${trimmedEmail}\n\n${trimmedMessage}`
    );

    window.location.href = `mailto:${contact.email}?subject=${subject}&body=${body}`;
    setFormStatus(`Email draft prepared for ${contact.email}.`);
    setSenderName('');
    setSenderEmail('');
    setMessage('');
  };

  return (
    <section
      id="contact"
      aria-label="Contact details"
      className="section-anchor"
    >
      {/* PLACEHOLDER - replace in CONTACT object */}
      <div className="neumorphic-card p-6 sm:p-8 flex flex-col gap-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 className="pill-label m-0">Contact</h2>
          <p className="m-0 font-body text-[14px] text-white/90">
            {contact.name} — {contact.role}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
          {/* Contact Details (read strictly from CONTACT object) */}
          <div className="flex flex-col gap-4">
            {/* Email Row */}
            <div className="rounded-[12px] bg-white/14 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="m-0 font-body text-[12px] uppercase tracking-wider text-white/75">
                  Email
                </p>
                <a
                  href={`mailto:${contact.email}`}
                  className="font-body text-[14px] sm:text-[15px] font-medium text-white underline-offset-4 hover:underline break-all"
                >
                  {contact.email}
                </a>
              </div>
              <button
                type="button"
                onClick={handleCopyEmail}
                className="pill-button text-[13px] px-4 py-2 min-h-[44px] sm:min-h-0"
              >
                {copied ? 'Copied!' : 'Copy email'}
              </button>
            </div>

            {/* WhatsApp Row */}
            <div className="rounded-[12px] bg-white/14 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="m-0 font-body text-[12px] uppercase tracking-wider text-white/75">
                  WhatsApp
                </p>
                <a
                  href={`https://wa.me/${contact.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-body text-[14px] sm:text-[15px] font-medium text-white underline-offset-4 hover:underline"
                >
                  {contact.phone}
                </a>
              </div>
              <a
                href={`https://wa.me/${contact.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="social-box text-[13px] px-4 py-2 min-h-[44px] sm:min-h-0"
              >
                Message
              </a>
            </div>

            {/* Location Row */}
            <div className="rounded-[12px] bg-white/14 p-4">
              <p className="m-0 font-body text-[12px] uppercase tracking-wider text-white/75">
                Location
              </p>
              <p className="m-0 font-body text-[14px] sm:text-[15px] font-medium text-white">
                {contact.location}
              </p>
            </div>
          </div>

          {/* Contact Form (reads recipient email from CONTACT.email) */}
          <form onSubmit={handleFormSubmit} className="flex flex-col gap-3.5" noValidate>
            <div>
              <label htmlFor="contact-name" className="block font-body text-[12px] text-white/90 mb-1">
                Your Name
              </label>
              <input
                id="contact-name"
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder="Enter your name"
                className="contact-input min-h-[44px]"
                required
              />
            </div>

            <div>
              <label htmlFor="contact-email" className="block font-body text-[12px] text-white/90 mb-1">
                Your Email
              </label>
              <input
                id="contact-email"
                type="email"
                value={senderEmail}
                onChange={(e) => setSenderEmail(e.target.value)}
                placeholder="Enter your email"
                className="contact-input min-h-[44px]"
                required
              />
            </div>

            <div>
              <label htmlFor="contact-message" className="block font-body text-[12px] text-white/90 mb-1">
                Message
              </label>
              <textarea
                id="contact-message"
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell me about your design project..."
                className="contact-input resize-y"
                required
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <button type="submit" className="pill-button min-h-[44px]">
                Send Message
              </button>
              {formStatus && (
                <p role="status" className="m-0 font-body text-[12px] text-white/95">
                  {formStatus}
                </p>
              )}
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}
