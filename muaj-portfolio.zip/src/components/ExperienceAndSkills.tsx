import { useEffect, useRef, useState } from 'react';
import { ExperienceItem } from '../types/portfolio';
import lightroomIcon from '../assets/icons/icon1.jpg';
import pixellabIcon from '../assets/icons/icon2.jpg';
import picsartIcon from '../assets/icons/icon3.jpg';
import canvaIcon from '../assets/icons/icon4.jpg';

const EXPERIENCE_ITEMS: ExperienceItem[] = [
  {
    year: '2020',
    lines: ['Started learning graphic design', 'Practiced logo and poster design'],
  },
  {
    year: '2021',
    lines: ['Began freelance social media designs', 'Built a personal design style'],
  },
  {
    year: '2022',
    lines: ['Worked on branding projects', 'Designed for local businesses'],
  },
  {
    year: '2025',
    lines: ['Expanded into advanced design and editing'],
  },
];

const SKILLS = [
  'Logo Design',
  'Social Media Design',
  'Photo Editing',
  'Branding',
];

export function ExperienceAndSkills() {
  const expRef = useRef<HTMLDivElement>(null);
  const [expVisible, setExpVisible] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (expVisible) return;
    const node = expRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setExpVisible(true);
            observer.disconnect();
            break;
          }
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [expVisible]);

  return (
    <section
      id="experience"
      aria-label="Experience, skills, and software"
      className="section-anchor"
    >
      <div className="two-col-section">
        {/* Left Column: My Experience */}
        <div ref={expRef} className="relative pt-5">
          <div className="relative z-10 ml-5 -mb-5">
            <h2 className="pill-label m-0">My Experience</h2>
          </div>
          <div className="experience-panel pt-9">
            <div className="flex flex-col gap-5">
              {EXPERIENCE_ITEMS.map((item, idx) => (
                <div
                  key={item.year}
                  className={`experience-row flex flex-col sm:flex-row sm:items-start gap-1.5 sm:gap-5 ${
                    expVisible ? 'is-visible' : ''
                  }`}
                  style={{ transitionDelay: `${idx * 100}ms` }}
                >
                  <span className="font-display text-[24px] leading-tight text-white shrink-0 min-w-[74px]">
                    {item.year}
                  </span>
                  <div className="font-body text-[13px] leading-[1.6] text-white/95">
                    {item.lines.map((line) => (
                      <p key={line} className="m-0">
                        {line}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Skill & Software */}
        <div className="flex flex-col gap-7 pt-5">
          <div className="flex flex-col items-start gap-4">
            <h2 className="pill-label m-0">Skill</h2>
            <div className="flex flex-wrap gap-2.5">
              {SKILLS.map((skill) => (
                <span key={skill} className="skill-tag">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-col items-start gap-4">
            <h2 className="pill-label m-0">Software</h2>

            {/* ================================================================
                REPLACE APP ICONS HERE:
                Official icons imported from src/assets/icons/.
                ================================================================ */}
            <div className="neumorphic-card w-full p-5 sm:p-6">
              <div className="flex flex-wrap items-center gap-3.5">
                {/* 1. Pixellab */}
                <span
                  className="software-badge"
                  style={{ background: '#2596E8' }}
                  title="Pixellab"
                >
                  <img
                    src={pixellabIcon}
                    alt="Pixellab"
                    className="scale-[1.12]"
                  />
                </span>

                {/* 2. Canva */}
                <span
                  className="software-badge"
                  style={{ background: '#FFFFFF' }}
                  title="Canva"
                >
                  <img
                    src={canvaIcon}
                    alt="Canva"
                    className="scale-[1.36]"
                  />
                </span>

                {/* 3. PicsArt */}
                <span
                  className="software-badge"
                  style={{ background: '#8E3CE4' }}
                  title="PicsArt"
                >
                  <img
                    src={picsartIcon}
                    alt="PicsArt"
                    className="scale-[1.12]"
                  />
                </span>

                {/* 4. Adobe Lightroom */}
                <span
                  className="software-badge"
                  style={{ background: '#001E36' }}
                  title="Adobe Lightroom"
                >
                  <img
                    src={lightroomIcon}
                    alt="Adobe Lightroom"
                    className="scale-[1.12]"
                  />
                </span>

                {/* 5. Pinterest (red P) */}
                <span
                  className="software-badge"
                  style={{ background: '#E60023' }}
                  title="Pinterest"
                  aria-label="Pinterest"
                >
                  <span className="font-display text-[21px] font-bold text-white leading-none">
                    P
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
