export function Footer() {
  return (
    <footer className="portfolio-container pb-10">
      <div className="flex items-center justify-center gap-4">
        <div
          aria-hidden="true"
          className="w-[56px] h-[56px] rounded-full flex items-center justify-center shrink-0 font-display text-[24px] text-white"
          style={{
            backgroundColor: '#A89BDB',
            boxShadow:
              '0 8px 18px rgba(0, 0, 0, 0.20), inset 0 2px 3px rgba(255, 255, 255, 0.25)',
          }}
        >
          M
        </div>
        <p className="m-0 font-body text-[14px] sm:text-[15px] text-white">
          Archive by <strong className="font-bold">@muaj_bin_ashraf</strong>
        </p>
      </div>
    </footer>
  );
}
