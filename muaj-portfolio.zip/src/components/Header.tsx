import { useState, useEffect, useRef } from 'react';
import { NavItem, NavSectionId } from '../types/portfolio';

interface HeaderProps {
  activeSection: NavSectionId;
  onNavigate: (id: NavSectionId) => void;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', href: '#home' },
  { id: 'service', label: 'Service', href: '#service' },
  { id: 'about', label: 'About me', href: '#about' },
  { id: 'project', label: 'Project', href: '#project' },
];

export function Header({ activeSection, onNavigate }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!menuOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMenuOpen(false);
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (headerRef.current && !headerRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [menuOpen]);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, item: NavItem) => {
    e.preventDefault();
    setMenuOpen(false);
    onNavigate(item.id);
  };

  return (
    <div className="portfolio-container sticky top-3 z-50 mt-3">
      <header ref={headerRef} className="site-header liquid-glass relative">
        <div className="flex items-center justify-between gap-4">
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              setMenuOpen(false);
              onNavigate('home');
            }}
            className="logo-box"
          >
            Portofolio
          </a>

          <nav aria-label="Primary navigation" className="desktop-nav flex items-center gap-2">
            {NAV_ITEMS.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={(e) => handleLinkClick(e, item)}
                  className={`nav-link ${isActive ? 'is-active' : ''}`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {item.label}
                </a>
              );
            })}
          </nav>

          <button
            type="button"
            className="mobile-menu-btn"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav-dropdown"
            onClick={() => setMenuOpen((prev) => !prev)}
          >
            <span aria-hidden="true">☰</span>
          </button>
        </div>

        {menuOpen && (
          <nav
            id="mobile-nav-dropdown"
            aria-label="Mobile navigation"
            className="liquid-glass mt-3 rounded-[24px] p-3 flex flex-col gap-2"
          >
            {NAV_ITEMS.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={(e) => handleLinkClick(e, item)}
                  className={`nav-link w-full justify-start ${isActive ? 'is-active' : ''}`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  {item.label}
                </a>
              );
            })}
          </nav>
        )}
      </header>
    </div>
  );
}
