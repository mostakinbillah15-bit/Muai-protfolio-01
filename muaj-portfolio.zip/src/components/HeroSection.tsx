import { ContactConfig } from '../types/portfolio';

interface HeroSectionProps {
  contact: ContactConfig;
}

export function HeroSection({ contact }: HeroSectionProps) {
  return (
    <section id="about" aria-labelledby="hero-heading" className="section-anchor">
      <div className="hero-grid">
        <div className="hero-text-band">
          <h1 id="hero-heading" className="hero-title">
            ABOUT ME
          </h1>
          <p className="hero-body">
            Hello everyone, I&apos;m {contact.name}, a {contact.role.toLowerCase()}. I create
            logos, social media designs and brand visuals that look clean and tell a story.
          </p>
        </div>

        {/* ================================================================
            REPLACE PHOTO HERE:
            To add your real portrait, add "has-photo" to the div className below
            and replace the <span> with a single <img> tag:
            <img src="/your-photo.jpg" alt={`${contact.name}, ${contact.role}`} />
            ================================================================ */}
        <div className="portrait-card">
          <span className="font-body text-[15px] font-medium text-white/90">
            Your photo here
          </span>
        </div>
      </div>
    </section>
  );
}
