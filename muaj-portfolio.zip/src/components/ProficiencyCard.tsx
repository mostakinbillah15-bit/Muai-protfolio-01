import { useEffect, useRef, useState } from 'react';
import { ProficiencyItem } from '../types/portfolio';

const PROFICIENCY_ITEMS: ProficiencyItem[] = [
  { name: 'Pixellab', percentage: 95 },
  { name: 'Canva', percentage: 89 },
  { name: 'Picsart', percentage: 74 },
  { name: 'Lightroom', percentage: 76 },
];

export function ProficiencyCard() {
  const cardRef = useRef<HTMLDivElement>(null);
  const [hasAnimated, setHasAnimated] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (hasAnimated) return;
    const node = cardRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setHasAnimated(true);
            observer.disconnect();
            break;
          }
        }
      },
      { threshold: 0.25 }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [hasAnimated]);

  return (
    <section
      id="service"
      aria-label="Software proficiency"
      className="section-anchor"
    >
      <div ref={cardRef} className="neumorphic-card p-6 sm:p-8">
        <div className="proficiency-grid">
          {PROFICIENCY_ITEMS.map((item) => (
            <div key={item.name} className="flex flex-col gap-2.5">
              <div className="flex items-center justify-between gap-2 text-[14px] sm:text-[15px] font-medium text-white">
                <span>{item.name}</span>
                <span>{item.percentage}%</span>
              </div>
              <div
                className="progress-track"
                role="progressbar"
                aria-label={`${item.name} proficiency`}
                aria-valuenow={item.percentage}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                <div
                  className="progress-fill"
                  style={{ width: hasAnimated ? `${item.percentage}%` : '0%' }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
