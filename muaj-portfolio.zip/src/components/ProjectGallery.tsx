import { useEffect, useRef, useState } from 'react';
import { UploadedDesign } from '../types/portfolio';
import {
  loadDesignsFromStorage,
  resizeAndCompressImage,
  saveDesignsToStorage,
} from '../utils/imageProcessor';

const PLACEHOLDER_TILES = ['Design 1', 'Design 2', 'Design 3', 'Design 4'];

export function ProjectGallery() {
  const [designs, setDesigns] = useState<UploadedDesign[]>(() =>
    loadDesignsFromStorage()
  );
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [lightboxItem, setLightboxItem] = useState<UploadedDesign | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!lightboxItem) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightboxItem(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxItem]);

  const handleUploadClick = () => {
    setErrorMessage(null);
    fileInputRef.current?.click();
  };

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;

    const files = Array.from(fileList);
    e.target.value = '';

    setIsUploading(true);
    setErrorMessage(null);

    try {
      const processed: UploadedDesign[] = [];
      for (const file of files) {
        const item = await resizeAndCompressImage(file);
        processed.push(item);
      }

      const nextDesigns = [...processed, ...designs];
      const result = saveDesignsToStorage(nextDesigns);

      if (!result.ok) {
        setErrorMessage(
          result.reason === 'quota'
            ? 'Browser storage is full. Please delete some existing designs before uploading new ones.'
            : 'Could not save the uploaded designs to browser storage.'
        );
        return;
      }

      setDesigns(nextDesigns);
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'Could not process the selected image.'
      );
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteDesign = (
    e: React.MouseEvent<HTMLButtonElement>,
    id: string
  ) => {
    e.stopPropagation();
    setErrorMessage(null);
    const nextDesigns = designs.filter((d) => d.id !== id);
    saveDesignsToStorage(nextDesigns);
    setDesigns(nextDesigns);
    if (lightboxItem?.id === id) {
      setLightboxItem(null);
    }
  };

  return (
    <section
      id="project"
      aria-label="My Project Gallery"
      className="section-anchor"
    >
      <div className="neumorphic-card p-6 sm:p-8 flex flex-col gap-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 className="pill-label m-0">My Project</h2>

          <button
            type="button"
            onClick={handleUploadClick}
            disabled={isUploading}
            className="pill-button"
          >
            <span>{isUploading ? 'Uploading...' : '+ Upload Design'}</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            aria-label="Upload design images"
            onChange={handleFilesSelected}
            className="hidden"
          />
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="rounded-[12px] border border-white/60 bg-black/25 px-4 py-3 text-[13px] font-medium text-white"
          >
            {errorMessage}
          </div>
        )}

        {/* Note for owner: Images uploaded here are saved in this browser's localStorage.
            To show designs to all visitors across devices, host image files in the project
            folder or connect a backend storage service (such as Firebase or Supabase). */}
        {designs.length === 0 ? (
          <div className="gallery-grid">
            {PLACEHOLDER_TILES.map((label) => (
              <div
                key={label}
                className="gallery-thumb flex items-center justify-center p-3 text-center"
              >
                <span className="font-body text-[13px] font-medium text-white/85">
                  {label}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="gallery-grid">
            {designs.map((design) => (
              <div
                key={design.id}
                role="button"
                tabIndex={0}
                onClick={() => setLightboxItem(design)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setLightboxItem(design);
                  }
                }}
                aria-label={`View ${design.name} in lightbox`}
                className="gallery-thumb gallery-thumb-interactive"
              >
                <img
                  src={design.dataUrl}
                  alt={design.name}
                  className="w-full h-full object-cover block"
                />
                <button
                  type="button"
                  onClick={(e) => handleDeleteDesign(e, design.id)}
                  aria-label={`Delete ${design.name}`}
                  className="thumb-delete-btn"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox Modal */}
      {lightboxItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={lightboxItem.name}
          onClick={() => setLightboxItem(null)}
          className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-5"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-[90vw] max-h-[88vh] flex items-center justify-center"
          >
            <img
              src={lightboxItem.dataUrl}
              alt={lightboxItem.name}
              className="max-w-full max-h-[85vh] rounded-[16px] object-contain shadow-2xl"
            />
            <button
              type="button"
              onClick={() => setLightboxItem(null)}
              aria-label="Close image preview"
              className="absolute -top-3 -right-3 w-9 h-9 rounded-full bg-black/80 text-white border border-white/50 flex items-center justify-center text-[20px] leading-none cursor-pointer hover:bg-black"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
