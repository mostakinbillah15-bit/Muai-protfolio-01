export type NavSectionId = 'home' | 'service' | 'about' | 'project';

export interface NavItem {
  id: NavSectionId;
  label: string;
  href: string;
}

export interface ProficiencyItem {
  name: string;
  percentage: number;
}

export interface ExperienceItem {
  year: string;
  lines: string[];
}

export interface UploadedDesign {
  id: string;
  name: string;
  dataUrl: string;
  createdAt: number;
}

export interface ContactConfig {
  name: string;
  role: string;
  email: string;
  whatsapp: string;
  phone: string;
  location: string;
  social: string;
}
