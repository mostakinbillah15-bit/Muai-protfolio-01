import { UploadedDesign } from '../types/portfolio';

export const STORAGE_KEY = 'muaj_portfolio_designs_v1';
const MAX_WIDTH = 600;
const JPEG_QUALITY = 0.8;

/**
 * Resizes an image file to at most 600px wide and compresses it as a JPEG (~0.8 quality).
 */
export function resizeAndCompressImage(file: File): Promise<UploadedDesign> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error(`"${file.name}" is not a supported image file.`));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read "${file.name}".`));

    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error(`Could not decode "${file.name}".`));

      img.onload = () => {
        const scale = img.width > MAX_WIDTH ? MAX_WIDTH / img.width : 1;
        const targetWidth = Math.max(1, Math.round(img.width * scale));
        const targetHeight = Math.max(1, Math.round(img.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable.'));
          return;
        }

        // Fill white behind transparent PNG/WebP before JPEG encoding
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);

        const dataUrl = canvas.toDataURL('image/jpeg', JPEG_QUALITY);
        const cleanTitle = file.name.replace(/\.[^/.]+$/, '') || 'Uploaded design';

        resolve({
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          name: cleanTitle,
          dataUrl,
          createdAt: Date.now(),
        });
      };

      img.src = String(reader.result);
    };

    reader.readAsDataURL(file);
  });
}

export function loadDesignsFromStorage(): UploadedDesign[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is UploadedDesign =>
        Boolean(item && typeof item.id === 'string' && typeof item.dataUrl === 'string')
    );
  } catch {
    return [];
  }
}

export function saveDesignsToStorage(designs: UploadedDesign[]): { ok: true } | { ok: false; reason: 'quota' | 'unknown' } {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(designs));
    return { ok: true };
  } catch (err) {
    const isQuota =
      err instanceof DOMException &&
      (err.name === 'QuotaExceededError' ||
        err.name === 'NS_ERROR_DOM_QUOTA_REACHED' ||
        err.code === 22 ||
        err.code === 1014);
    return { ok: false, reason: isQuota ? 'quota' : 'unknown' };
  }
}
